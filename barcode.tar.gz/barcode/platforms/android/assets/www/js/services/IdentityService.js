'use strict';
var IDENTITY_URI = "Identity"
var DRIVER_URI = "Driver"
var IDENTITYTYPE_URI = "IdentityType"

services.factory('IdentityService', function ($http, $q ) {
    // Return public API.
    return({
        createIdentity:createIdentity,
        updateIdentity:updateIdentity,
        getAllIdentitys:getAllIdentitys,        getAllIdentitysByDriverId:getAllIdentitysByDriverId,        getAllIdentitysByIdentityTypeId:getAllIdentitysByIdentityTypeId,
        getIdentityById: getIdentityById
    });

    function createIdentity( identity ) {
        var request = $http({
            method: "post",
            crossDomain:true,
            url:  BASE_API + IDENTITY_URI,
            data:identity
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function updateIdentity( identity ) {
        var request = $http({
            method: "put",
            crossDomain:true,
            url:  BASE_API + IDENTITY_URI,
            data:identity
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getIdentityById(identityId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + IDENTITY_URI+ "/" +identityId
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getAllIdentitys(){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API +  IDENTITY_URI 
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getAllIdentitysByDriverId(driverId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + IDENTITY_URI+ "/" +DRIVER_URI+ "/" +driverId 
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getAllIdentitysByIdentityTypeId(identityTypeId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + IDENTITY_URI+ "/" +IDENTITYTYPE_URI+ "/" +identityTypeId 
        });
        return( request.then( handleSuccess, handleError ) );
    }
  
});