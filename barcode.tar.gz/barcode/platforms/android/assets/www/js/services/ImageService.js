'use strict';
var IMAGE_URI = "Image"
var TRUCK_URI = "Truck"
var TRUCKDOCUMENT_URI = "TruckDocument"


services.factory('ImageService', function ($http, $q , imageFileService) {
    // Return public API.
    return({
        createImage:createImage,
        updateImage:updateImage,
        getAllImages:getAllImages,
        getAllImagesByTruckId:getAllImagesByTruckId,
        getAllImagesByTruckDocumentId:getAllImagesByTruckDocumentId,
        getImageById: getImageById,
        uploadFile:uploadFile,
        setTruck:setTruck,
        setTruckDocument:setTruckDocument

    });

    function createImage( image ) {
        var request = $http({
            method: "post",
            crossDomain:true,
            url:  BASE_API + IMAGE_URI,
            data:image
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function updateImage( image ) {
        var request = $http({
            method: "put",
            crossDomain:true,
            url:  BASE_API + IMAGE_URI,
            data:image
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getImageById(imageId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + IMAGE_URI+ "/" +imageId
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getAllImages(){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API +  IMAGE_URI 
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getAllImagesByTruckId(truckId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + IMAGE_URI+ "/" +TRUCK_URI+ "/" +truckId 
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getAllImagesByTruckDocumentId(truckDocumentId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + IMAGE_URI+ "/" +TRUCKDOCUMENT_URI+ "/" +truckDocumentId 
        });
        return( request.then( handleSuccess, handleError ) );
    }

 function uploadFile( file, image ) {
      image.fileName =file.name;
      image.fileSize = file.size;
      image.fileType = file.type;
      var formData = new FormData();
      formData.append('file', file);
      formData.append('image', JSON.stringify(image));
        var request = $http({

            method: "post",
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined},
            //headers: {'Content-Type': 'multipart/form-data'},
            url:  BASE_API + IMAGE_URI + "/Upload" ,
            crossDomain:true,
            data:formData
        });
        
        if(imageFileService.length>0){
                for(var i=0;i<imageFileService.length;i++){
                  imageFileService.pop(i);
                }
        }

        return( request.then( handleSuccess, handleError ) );
    }


     function setTruck(imageId,truckId,defaultImage){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API +  IMAGE_URI + "/SetTruck/Image/" + imageId + "/Truck/" + truckId + "/DefaultImage/" + defaultImage 
        });
        return( request.then( handleSuccess, handleError ) );
    }

     function setTruckDocument(imageId,truckDocumentId,defaultImage){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API +  IMAGE_URI + "/SetTruckDocument/Image/" + imageId + "/TruckDocument/" + truckDocumentId + "/DefaultImage/" + defaultImage 
        });
        return( request.then( handleSuccess, handleError ) );
    }

  
});
