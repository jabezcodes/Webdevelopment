'use strict';
var TRIPSTATUS_URI = "TripStatus"

services.factory('TripStatusService', function ($http, $q ) {
    // Return public API.
    return({
        createTripStatus:createTripStatus,
        updateTripStatus:updateTripStatus,
        getAllTripStatuss:getAllTripStatuss,
        getTripStatusById: getTripStatusById
    });

    function createTripStatus( tripStatus ) {
        var request = $http({
            method: "post",
            crossDomain:true,
            url:  BASE_API + TRIPSTATUS_URI,
            data:tripStatus
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function updateTripStatus( tripStatus ) {
        var request = $http({
            method: "put",
            crossDomain:true,
            url:  BASE_API + TRIPSTATUS_URI,
            data:tripStatus
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getTripStatusById(tripStatusId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + TRIPSTATUS_URI+ "/" +tripStatusId
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getAllTripStatuss(){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API +  TRIPSTATUS_URI 
        });
        return( request.then( handleSuccess, handleError ) );
    }
  
});