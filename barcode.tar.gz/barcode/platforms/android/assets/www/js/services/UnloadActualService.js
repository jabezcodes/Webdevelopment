'use strict';
var UNLOADACTUAL_URI = "UnloadActual"
var UNLOADPLAN_URI = "UnloadPlan"

services.factory('UnloadActualService', function ($http, $q ) {
    // Return public API.
    return({
        createUnloadActual:createUnloadActual,
        updateUnloadActual:updateUnloadActual,
        getAllUnloadActuals:getAllUnloadActuals,        getAllUnloadActualsByUnloadPlanId:getAllUnloadActualsByUnloadPlanId,
        getUnloadActualById: getUnloadActualById
    });

    function createUnloadActual( unloadActual ) {
        var request = $http({
            method: "post",
            crossDomain:true,
            url:  BASE_API + UNLOADACTUAL_URI,
            data:unloadActual
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function updateUnloadActual( unloadActual ) {
        var request = $http({
            method: "put",
            crossDomain:true,
            url:  BASE_API + UNLOADACTUAL_URI,
            data:unloadActual
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getUnloadActualById(unloadActualId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + UNLOADACTUAL_URI+ "/" +unloadActualId
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getAllUnloadActuals(){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API +  UNLOADACTUAL_URI 
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getAllUnloadActualsByUnloadPlanId(unloadPlanId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + UNLOADACTUAL_URI+ "/" +UNLOADPLAN_URI+ "/" +unloadPlanId 
        });
        return( request.then( handleSuccess, handleError ) );
    }
  
});