'use strict';
var TRIPASSIGNSTATUS_URI = "TripAssignStatus"

services.factory('TripAssignStatusService', function ($http, $q ) {
    // Return public API.
    return({
        createTripAssignStatus:createTripAssignStatus,
        updateTripAssignStatus:updateTripAssignStatus,
        getAllTripAssignStatuss:getAllTripAssignStatuss,
        getTripAssignStatusById: getTripAssignStatusById
    });

    function createTripAssignStatus( tripAssignStatus ) {
        var request = $http({
            method: "post",
            crossDomain:true,
            url:  BASE_API + TRIPASSIGNSTATUS_URI,
            data:tripAssignStatus
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function updateTripAssignStatus( tripAssignStatus ) {
        var request = $http({
            method: "put",
            crossDomain:true,
            url:  BASE_API + TRIPASSIGNSTATUS_URI,
            data:tripAssignStatus
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getTripAssignStatusById(tripAssignStatusId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + TRIPASSIGNSTATUS_URI+ "/" +tripAssignStatusId
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getAllTripAssignStatuss(){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API +  TRIPASSIGNSTATUS_URI 
        });
        return( request.then( handleSuccess, handleError ) );
    }
  
});