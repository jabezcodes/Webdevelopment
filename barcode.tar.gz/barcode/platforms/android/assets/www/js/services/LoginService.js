'use strict';
var DEPT_URI = "Login"

services.factory('LoginService', function ($http, $q ) {
    // Return public API.
  var login_url =  "http://166.62.84.223:8080/Dunamis/oauth/token?grant_type=password&client_id=restapp&client_secret=restapp";

    return {
    login: function(userName, password){
        alert();
     /* var url = login_url + "&username="  + userName +"&password=" + password;
            return $http.get(url).then(function(user){
        console.log(user);
        if(user!=undefined){
            return user;
        }
            });*/
        }
    }    
});