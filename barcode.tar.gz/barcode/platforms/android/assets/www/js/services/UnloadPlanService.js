'use strict';
var UNLOADPLAN_URI = "UnloadPlan"
var VESELHOLD_URI = "VeselHold"
var CONSIGNMENT_URI = "Consignment"

services.factory('UnloadPlanService', function ($http, $q ) {
    // Return public API.
    return({
        createUnloadPlan:createUnloadPlan,
        updateUnloadPlan:updateUnloadPlan,
        getAllUnloadPlans:getAllUnloadPlans,        getAllUnloadPlansByVeselHoldId:getAllUnloadPlansByVeselHoldId,        getAllUnloadPlansByConsignmentId:getAllUnloadPlansByConsignmentId,
        getUnloadPlanById: getUnloadPlanById
    });

    function createUnloadPlan( unloadPlan ) {
        var request = $http({
            method: "post",
            crossDomain:true,
            url:  BASE_API + UNLOADPLAN_URI,
            data:unloadPlan
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function updateUnloadPlan( unloadPlan ) {
        var request = $http({
            method: "put",
            crossDomain:true,
            url:  BASE_API + UNLOADPLAN_URI,
            data:unloadPlan
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getUnloadPlanById(unloadPlanId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + UNLOADPLAN_URI+ "/" +unloadPlanId
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getAllUnloadPlans(){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API +  UNLOADPLAN_URI 
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getAllUnloadPlansByVeselHoldId(veselHoldId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + UNLOADPLAN_URI+ "/" +VESELHOLD_URI+ "/" +veselHoldId 
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getAllUnloadPlansByConsignmentId(consignmentId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + UNLOADPLAN_URI+ "/" +CONSIGNMENT_URI+ "/" +consignmentId 
        });
        return( request.then( handleSuccess, handleError ) );
    }
  
});