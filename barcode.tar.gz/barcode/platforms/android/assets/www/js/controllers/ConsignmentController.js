'use strict';
/* Controllers */

myApp.controller('ConsignmentCtrl', ['$scope', '$location', '$http','$stateParams', '$sce','ConsignmentService', 
    function($scope, $location, $http, $stateParams, $sce, ConsignmentService ){

    $scope.showConsignmentList=true;
    $scope.showConsignmentForm=false;

    $scope.consignment = {};
    $scope.consignments = {};  

    $scope.buttonTextConsignment = "";

    $scope.param1 = "";
    $scope.param2 = "";
    
    if( $stateParams.param2 != undefined){
        $scope.param2 = $stateParams.param2;
    }    

    if( $stateParams.param1 != undefined){
        $scope.param1 = $stateParams.param1;
    }

    $scope.currentPageConsignment = 1;
    $scope.pageSizeConsignment = 6;

    $scope.sortKeyConsignment = "";
    $scope.consignmentReverse = false; 

    $scope.sortConsignment = function(columnName,reverse){
        $scope.sortKeyConsignment = columnName;
        $scope.consignmentReverse = !$scope.consignmentReverse; 
    }

      
    $scope.loadConsignmentForm = function(consignment,isEdit){
        if (isEdit==1){
            $scope.buttonTextConsignment = "Update";
            $scope.consignment = consignment 
        }    
        else{
            $scope.buttonTextConsignment = "Add";
            $scope.consignment = {} ;

        }    
                   
        $scope.showConsignmentForm= true;
        $scope.showConsignmentList= false;
       }


    $scope.saveConsignment = function(consignment){
        if ($scope.buttonTextConsignment=="Add")
            ConsignmentService.createConsignment(consignment)
                .then(
                    function( consignment ) {
                        if(consignment!=undefined){
                            $scope.consignment = {};
                            $scope.hideConsignmentForm();
                            $scope.getAllConsignments();
                            alert("Consignment Added!");
                        }else{
                        }
                    }
                );
        else{
            ConsignmentService.updateConsignment(consignment)
                .then(
                    function( consignment ) {
                        if(consignment!=undefined){
                            $scope.consignment = {};
                            $scope.hideConsignmentForm(); 
                            $scope.getAllConsignments();
                            alert("Consignment Updated!");
                        }else{
                        }
                    }
                );
            }
    }

    $scope.hideConsignmentForm = function(){
        $scope.showConsignmentForm= false;
        $scope.showConsignmentList= true;
    }

    $scope.getAllConsignments= function(){
        if( $scope.param1 != ""){
        }else{
            ConsignmentService.getAllConsignments()
                .then(
                    function( consignments ) {
                        if(consignments!=undefined){
                            $scope.consignments = consignments;
                            
                        }
                    }
                );
            }
        }    

    $scope.getAllConsignments();
}]);