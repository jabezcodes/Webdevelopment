'use strict';
/* Controllers */

myApp.controller('ConsignmentTruckCtrl', ['$scope', '$location', '$http','$stateParams', '$sce', '$cordovaBarcodeScanner', 'ConsignmentTruckService', 'ConsignmentService', 'GridDisplayService', 
    function($scope, $location, $http, $stateParams, $sce, $cordovaBarcodeScanner, ConsignmentTruckService , ConsignmentService,GridDisplayService){

    $scope.showConsignmentTruckList=true;
    $scope.showConsignmentTruckForm=false;

    $scope.consignmentTruck = {};
    $scope.consignmentTrucks = {};  
    $scope.consignments = {};
    $scope.consignment = {};

    $scope.buttonTextConsignmentTruck = "";

    $scope.param1 = "";
    $scope.param2 = "";
    
    if( $stateParams.param2 != undefined){
        $scope.param2 = $stateParams.param2;
    }    

    if( $stateParams.param1 != undefined){
        $scope.param1 = $stateParams.param1;
    }

    $scope.currentPageConsignmentTruck = 1;
    $scope.pageSizeConsignmentTruck = 6;

    $scope.sortKeyConsignmentTruck = "";
    $scope.consignmentTruckReverse = false; 

    $scope.sortConsignmentTruck = function(columnName,reverse){
        $scope.sortKeyConsignmentTruck = columnName;
        $scope.consignmentTruckReverse = !$scope.consignmentTruckReverse; 
    }


    $scope.getAllConsignments= function(){
        ConsignmentService.getAllConsignments()
            .then(
                function( consignments ) {
                    if(consignments!=undefined){
                        $scope.consignments = consignments;    
                    }
                }
            );
    }
       
    $scope.setConsignment= function(id){
        ConsignmentService.getConsignmentById(id)
            .then(
                function(consignment){
                    if(consignment!=undefined){
                        $scope.consignment=consignment;
                        $scope.param2=consignment.id;
                    }
                }
        );
    } 

    $scope.getAllConsignments();
      
    $scope.loadConsignmentTruckForm = function(consignmentTruck,isEdit){
        if (isEdit==1){
            $scope.buttonTextConsignmentTruck = "Update";
            $scope.consignmentTruck = consignmentTruck 
        }    
        else{
            $scope.buttonTextConsignmentTruck = "Add";
            $scope.consignmentTruck = {} ;

        }    
                   
        $scope.showConsignmentTruckForm= true;
        $scope.showConsignmentTruckList= false;
       }


    $scope.saveConsignmentTruck = function(consignmentTruck){
        if ($scope.buttonTextConsignmentTruck=="Add")
            ConsignmentTruckService.createConsignmentTruck(consignmentTruck)
                .then(
                    function( consignmentTruck ) {
                        if(consignmentTruck!=undefined){
                            $scope.consignmentTruck = {};
                            $scope.hideConsignmentTruckForm();
                            $scope.getAllConsignmentTrucks();
                            alert("ConsignmentTruck Added!");
                        }else{
                        }
                    }
                );
        else{
            ConsignmentTruckService.updateConsignmentTruck(consignmentTruck)
                .then(
                    function( consignmentTruck ) {
                        if(consignmentTruck!=undefined){
                            $scope.consignmentTruck = {};
                            $scope.hideConsignmentTruckForm(); 
                            $scope.getAllConsignmentTrucks();
                            alert("ConsignmentTruck Updated!");
                        }else{
                        }
                    }
                );
            }
    }

    $scope.hideConsignmentTruckForm = function(){
        $scope.showConsignmentTruckForm= false;
        $scope.showConsignmentTruckList= true;
    }

    $scope.getAllConsignmentTrucks= function(){
        if( $scope.param1 != ""){if($scope.param1 =="Consignment") {
            $scope.setConsignment($scope.param2);
            ConsignmentTruckService.getAllConsignmentTrucksByConsignmentId($scope.param2)
                 .then(
                    function( consignmentTrucks ) {
                        if(consignmentTrucks!=undefined){
                            $scope.consignmentTrucks = consignmentTrucks;                
                            }
                        }
                    );
        }
        }else{
            ConsignmentTruckService.getAllConsignmentTrucks()
                .then(
                    function( consignmentTrucks ) {
                        if(consignmentTrucks!=undefined){
                            $scope.consignmentTrucks = consignmentTrucks;
                            
                        }
                    }
                );
            }
        }    
    
    $scope.param1 = "Consignment";
    $scope.param2 = 1;
    $scope.getAllConsignmentTrucks();



    $scope.loadTrip= function(consignmentTruckId){
        $location.url("app/Trip/ConsignmentTruck/" + consignmentTruckId)
    }



    $scope.scanBarcode = function() {


     $cordovaBarcodeScanner.scan().then(function(imageData) {
            //alert(imageData.text);
            $scope.loadTrip(imageData.text);
            //alert(imageData.text);

            console.log("Barcode Format -> " + imageData.format);
            console.log("Cancelled -> " + imageData.cancelled);
        }, function(error) {
            console.log("An error happened -> " + error);
        });
    };

}]);