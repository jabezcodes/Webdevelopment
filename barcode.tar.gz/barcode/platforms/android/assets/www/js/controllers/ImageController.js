'use strict';
/* Controllers */

myApp.controller('ImageCtrl', ['$scope', '$location', '$http','$stateParams', '$sce','ImageService', 'TruckService', 'imageFileService', '$cordovaCamera', '$cordovaFile',
    function($scope, $location, $http, $stateParams, $sce, ImageService , TruckService ,imageFileService, $cordovaCamera, $cordovaFile){

    $scope.identitys = {};
    $scope.identity = {};
    $scope.trucks = {};
    $scope.truck = {};



    $scope.imageURL = BASE_API+"Image/ImageById/";

    $scope.buttonTextImage = "";

    $scope.param1 = "";
    $scope.param2 = "";
    
    if( $stateParams.param2 != undefined){
        $scope.param2 = $stateParams.param2;
    }    

    if( $stateParams.param1 != undefined){
        $scope.param1 = $stateParams.param1;
    }

    $scope.currentPageImage = 1;
    $scope.pageSizeImage = 6;

    $scope.sortKeyImage = "";
    $scope.imageReverse = false; 

    $scope.sortImage = function(columnName,reverse){
        $scope.sortKeyImage = columnName;
        $scope.imageReverse = !$scope.imageReverse; 
    }



    $scope.getAllTrucks= function(){
        TruckService.getAllTrucks()
            .then(
                function( trucks ) {
                    if(trucks!=undefined){
                        $scope.trucks = trucks;    
                    }
                }
            );
    }
       
    $scope.setTruck= function(id){
        TruckService.getTruckById(id)
            .then(
                function(truck){
                    if(truck!=undefined){
                        $scope.truck=truck;
                        $scope.param2=truck.id;
                    }
                }
        );
    } 

    $scope.getAllTrucks();


    $scope.loadImageForm = function(image,isEdit){
        if (isEdit==1){
            $scope.buttonTextImage = "Update";
            $scope.image = image
        }    
        else{
            $scope.buttonTextImage = "Add";
            $scope.image = {} ;

        } 

        $scope.showImageForm= true;
        $scope.showImageList= false;      
    }

    $scope.saveImage = function(image){
        if($scope.buttonTextImage=="Add"){
               if(image.defaultImage==undefined) image.defaultImage = false 
               
               var tempDefaultImage = image.defaultImage; //store false in the first store
               image.defaultImage = false;

               if (imageFileService.length>0){
                ImageService.uploadFile(imageFileService[0],image)
                    .then(
                        function( image ) {
                            if(image!=undefined){
                                alert("Image Added!");

                                if($scope.truck!={}){
                                    ImageService.setTruck(image.id,$scope.truck.id,tempDefaultImage)
                                    .then(
                                    function( image ) {
                                        if(image!=undefined){
                                            console.log("Image Updated with truck!");
                                            $scope.getAllImages(); //repeated due to async
                                            $scope.hideImageForm(); //repeated due to async
                                        }
                                    });
                                 } 

                                 //DO same for driver doc   

                                /* if($scope.truckDocument!={}){
                                    ImageService.setTruckDocument(image.id,$scope.truckDocument.id,tempDefaultImage)
                                    .then(
                                    function( image ) {
                                        if(image!=undefined){
                                            console.log("Image Updated with truckDocument!");
                                            $scope.hideImageEditForm(image.id);
                                        }
                                    });
                                 } */

                                 //Till this

                                 

                            }
                        }
                    );
                }else{
                    alert("Pl include file")
                }
            }else{
                if (imageFileService.length>0){
                    alert("You cannot replace an image, pls delete.");
                }else{
                    ImageService.updateImage(image)
                    .then(
                        function( image ) {
                            if(image!=undefined){
                                alert("Image Updated!");
                                $scope.hideImageEditForm(image.id);

                            }
                        }
                    );
                }
            }
    }

$scope.picData = {};

$scope.addImage = function() {
 
        var options =   {
            quality: 50,
            destinationType: Camera.DestinationType.DATA_URI,
            sourceType: 1,      // 0:Photo Library, 1=Camera, 2=Saved Photo Album
            encodingType: 0     // 0=JPG 1=PNG
        }
        navigator.camera.getPicture(onSuccess,onFail,options);
    }
    var onSuccess = function(FILE_URI) {
        console.log(FILE_URI);
        window.resolveLocalFileSystemURL(FILE_URI, function(fileEntry) {
            console.log(fileEntry);
            ImageService.uploadFile(FILE_URI, {})
                    .then(
                        function( fileEntry ) {
                            if(fileEntry!=undefined){
                                alert("Image Updated!");
                            }
                        }
                    );
     });
    };
    var onFail = function(e) {
        console.log("On fail " + e);
    }


}]);