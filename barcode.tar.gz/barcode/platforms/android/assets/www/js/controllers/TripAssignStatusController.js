'use strict';
/* Controllers */

myApp.controller('TripAssignStatusCtrl', ['$scope', '$location', '$http','$stateParams', '$sce','TripAssignStatusService', 
    function($scope, $location, $http, $stateParams, $sce, TripAssignStatusService ){

    $scope.showTripAssignStatusList=true;
    $scope.showTripAssignStatusForm=false;

    $scope.tripAssignStatus = {};
    $scope.tripAssignStatuss = {};  

    $scope.buttonTextTripAssignStatus = "";

    $scope.param1 = "";
    $scope.param2 = "";
    
    if( $stateParams.param2 != undefined){
        $scope.param2 = $stateParams.param2;
    }    

    if( $stateParams.param1 != undefined){
        $scope.param1 = $stateParams.param1;
    }

    $scope.currentPageTripAssignStatus = 1;
    $scope.pageSizeTripAssignStatus = 6;

    $scope.sortKeyTripAssignStatus = "";
    $scope.tripAssignStatusReverse = false; 

    $scope.sortTripAssignStatus = function(columnName,reverse){
        $scope.sortKeyTripAssignStatus = columnName;
        $scope.tripAssignStatusReverse = !$scope.tripAssignStatusReverse; 
    }

      
    $scope.loadTripAssignStatusForm = function(tripAssignStatus,isEdit){
        if (isEdit==1){
            $scope.buttonTextTripAssignStatus = "Update";
            $scope.tripAssignStatus = tripAssignStatus 
        }    
        else{
            $scope.buttonTextTripAssignStatus = "Add";
            $scope.tripAssignStatus = {} ;

        }    
                   
        $scope.showTripAssignStatusForm= true;
        $scope.showTripAssignStatusList= false;
       }


    $scope.saveTripAssignStatus = function(tripAssignStatus){
        if ($scope.buttonTextTripAssignStatus=="Add")
            TripAssignStatusService.createTripAssignStatus(tripAssignStatus)
                .then(
                    function( tripAssignStatus ) {
                        if(tripAssignStatus!=undefined){
                            $scope.tripAssignStatus = {};
                            $scope.hideTripAssignStatusForm();
                            $scope.getAllTripAssignStatuss();
                            alert("TripAssignStatus Added!");
                        }else{
                        }
                    }
                );
        else{
            TripAssignStatusService.updateTripAssignStatus(tripAssignStatus)
                .then(
                    function( tripAssignStatus ) {
                        if(tripAssignStatus!=undefined){
                            $scope.tripAssignStatus = {};
                            $scope.hideTripAssignStatusForm(); 
                            $scope.getAllTripAssignStatuss();
                            alert("TripAssignStatus Updated!");
                        }else{
                        }
                    }
                );
            }
    }

    $scope.hideTripAssignStatusForm = function(){
        $scope.showTripAssignStatusForm= false;
        $scope.showTripAssignStatusList= true;
    }

    $scope.getAllTripAssignStatuss= function(){
        if( $scope.param1 != ""){
        }else{
            TripAssignStatusService.getAllTripAssignStatuss()
                .then(
                    function( tripAssignStatuss ) {
                        if(tripAssignStatuss!=undefined){
                            $scope.tripAssignStatuss = tripAssignStatuss;
                            
                        }
                    }
                );
            }
        }    

    $scope.getAllTripAssignStatuss();
}]);