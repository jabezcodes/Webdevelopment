'use strict';
/* Controllers */

myApp.controller('DocumentTypeCtrl', ['$scope', '$location', '$http','$routeParams', '$sce','DocumentTypeService', 
    function($scope, $location, $http, $routeParams, $sce, DocumentTypeService ){


    $scope.buttonTextDocumentType = "";

    $scope.param1 = "";
    $scope.param2 = "";
    
    if( $routeParams.param2 != undefined){
        $scope.param2 = $routeParams.param2;
    }    

    if( $routeParams.param1 != undefined){
        $scope.param1 = $routeParams.param1;
    }

    $scope.currentPageDocumentType = 1;
    $scope.pageSizeDocumentType = 6;

    $scope.sortKeyDocumentType = "";
    $scope.documentTypeReverse = false; 

    $scope.sortDocumentType = function(columnName,reverse){
        $scope.sortKeyDocumentType = columnName;
        $scope.documentTypeReverse = !$scope.documentTypeReverse; 
    }



    $scope.loadDocumentTypeForm = function(isEdit){
        if (isEdit==1){
            $scope.buttonTextDocumentType = "Update";
        }    
        else{
            $scope.buttonTextDocumentType = "Add";
        }       
    }


    $scope.saveDocumentType = function(documentType){
        if ($scope.buttonTextDocumentType=="Add")
            DocumentTypeService.createDocumentType(documentType)
                .then(
                    function( documentType ) {
                        if(documentType!=undefined){
                            //$.bootstrapGrowl("DocumentType Added!", { type: 'success',allow_dismiss: false,align: 'right', });
                            alert("DocumentType Added!");
                            $scope.hideDocumentTypeEditForm(documentType.id);
                        }else{
                        }
                    }
                );
        else{
            DocumentTypeService.updateDocumentType(documentType)
                .then(
                    function( documentType ) {
                        if(documentType!=undefined){
                            //$.bootstrapGrowl("DocumentType Updated!", { type: 'success',allow_dismiss: false,align: 'right', });
                            alert("DocumentType Updated!");
                            $scope.hideDocumentTypeEditForm(documentType.id);
                        }else{
                        }
                    }
                );
            }
    }


}]);