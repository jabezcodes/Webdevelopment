'use strict';
/* Controllers */

myApp.controller('TripStatusCtrl', ['$scope', '$location', '$http','$stateParams', '$sce','TripStatusService', 
    function($scope, $location, $http, $stateParams, $sce, TripStatusService ){

    $scope.showTripStatusList=true;
    $scope.showTripStatusForm=false;

    $scope.tripStatus = {};
    $scope.tripStatuss = {};  

    $scope.buttonTextTripStatus = "";

    $scope.param1 = "";
    $scope.param2 = "";
    
    if( $stateParams.param2 != undefined){
        $scope.param2 = $stateParams.param2;
    }    

    if( $stateParams.param1 != undefined){
        $scope.param1 = $stateParams.param1;
    }

    $scope.currentPageTripStatus = 1;
    $scope.pageSizeTripStatus = 6;

    $scope.sortKeyTripStatus = "";
    $scope.tripStatusReverse = false; 

    $scope.sortTripStatus = function(columnName,reverse){
        $scope.sortKeyTripStatus = columnName;
        $scope.tripStatusReverse = !$scope.tripStatusReverse; 
    }

      
    $scope.loadTripStatusForm = function(tripStatus,isEdit){
        if (isEdit==1){
            $scope.buttonTextTripStatus = "Update";
            $scope.tripStatus = tripStatus 
        }    
        else{
            $scope.buttonTextTripStatus = "Add";
            $scope.tripStatus = {} ;

        }    
                   
        $scope.showTripStatusForm= true;
        $scope.showTripStatusList= false;
       }


    $scope.saveTripStatus = function(tripStatus){
        if ($scope.buttonTextTripStatus=="Add")
            TripStatusService.createTripStatus(tripStatus)
                .then(
                    function( tripStatus ) {
                        if(tripStatus!=undefined){
                            $scope.tripStatus = {};
                            $scope.hideTripStatusForm();
                            $scope.getAllTripStatuss();
                            alert("TripStatus Added!");
                        }else{
                        }
                    }
                );
        else{
            TripStatusService.updateTripStatus(tripStatus)
                .then(
                    function( tripStatus ) {
                        if(tripStatus!=undefined){
                            $scope.tripStatus = {};
                            $scope.hideTripStatusForm(); 
                            $scope.getAllTripStatuss();
                            alert("TripStatus Updated!");
                        }else{
                        }
                    }
                );
            }
    }

    $scope.hideTripStatusForm = function(){
        $scope.showTripStatusForm= false;
        $scope.showTripStatusList= true;
    }

    $scope.getAllTripStatuss= function(){
        if( $scope.param1 != ""){
        }else{
            TripStatusService.getAllTripStatuss()
                .then(
                    function( tripStatuss ) {
                        if(tripStatuss!=undefined){
                            $scope.tripStatuss = tripStatuss;
                            
                        }
                    }
                );
            }
        }    

    $scope.getAllTripStatuss();
}]);