'use strict';
/* Controllers */

myApp.controller('SeaSummaryCtrl', ['$scope', '$interval', '$location', '$http','$stateParams', '$sce','ConsignmentService','VesselService', 
    function($scope, $interval, $location, $http, $stateParams, $sce, ConsignmentService,VesselService ){
     $scope.summary = {};

     $scope.value1=0;
     $scope.value2=0;
     $scope.value3=0;
     $scope.value4=0;
     $scope.recd=0;
     $scope.vessels;


       $scope.options1 = {
        animate : { enabled: true, duration: 1000, ease: 'bounce' },
        unit:'%',
        min: 0,
        max: 100,
        readOnly: true,
        size: 150,
        subText: {
          enabled: true,
          text: 'Planned',
          color: 'gray',
          font: 'auto'
        },
        trackWidth: 40,
        barWidth: 25,
        trackColor: '#ffffff',
        barColor: '#a4232d',
        dynamicOptions: true
      };

       $scope.options2 = {
        animate : { enabled: true, duration: 1000, ease: 'bounce' },
        unit:'%',
        min: 0,
        max: 120,
        readOnly: true,
        size: 150,
        subText: {
          enabled: true,
          text: 'Discharged',
          color: 'gray',
          font: 'auto'
        },
        trackWidth: 40,
        barWidth: 25,
        trackColor: '#ffffff',
        barColor: '#a4232d',
        dynamicOptions: true
      };

       $scope.options3 = {
        animate : { enabled: true, duration: 1000, ease: 'bounce' },
        unit:'%',
        min: 0,
        max: 110,
        readOnly: true,
        size: 150,
        subText: {
          enabled: true,
          text: 'In Transit',
          color: 'gray',
          font: 'auto'
        },
        trackWidth: 40,
        barWidth: 25,
        trackColor: '#ffffff',
        barColor: '#a4232d',
        dynamicOptions: true
      };

      $scope.options4 = {
        animate : { enabled: true, duration: 1000, ease: 'bounce' },
        unit:'%',
        min: 0,
        max: 110,
        readOnly: true,
        size: 150,
        subText: {
          enabled: true,
          text: 'Delivered',
          color: 'gray',
          font: 'auto'
        },
        trackWidth: 40,
        barWidth: 25,
        trackColor: '#ffffff',
        barColor: '#a4232d',
        dynamicOptions: true
      };
    

     
      $scope.getConsignmentSummary = function(){
        ConsignmentService.getSummary(1)
          .then(
              function( summary ) {
                if(summary!=undefined){
                    $scope.summary =summary;
                }
              }
          );
        }


    $scope.getConsignmentSummary();

   var flag =true;

    $scope.callAtInterval = function() {
      
        if(flag){
          //alert("ddf");
          
          $scope.value1 = ($scope.summary.totalPlannedTonnage/$scope.summary.vesselHoldTonnage)*100;
          $scope.value2 = ($scope.summary.actualTonnage/$scope.summary.vesselHoldTonnage)*100;
          $scope.value3 = ($scope.summary.inTransitTonnage/$scope.summary.vesselHoldTonnage)*100;
          $scope.value4 = ($scope.summary.deliveredTonnage/$scope.summary.vesselHoldTonnage)*100;
          flag = false;
        } 
        else {
          //alert("false");
          
          $scope.value1 = 0;
          $scope.value2 = 0;
          $scope.value3 = 0;
          $scope.value4 = 0;
          flag = true;
        }
    }

    
    $interval( function(){ $scope.callAtInterval(); }, 1000);
    

   $scope.getAllVessels= function(){
        
            VesselService.getAllVesselsByConsignmentId(1)
                 .then(
                    function( vessels ) {
                        if(vessels!=undefined){
                            $scope.vessels = vessels;                
                            }
                        }
                    );
       
        } 
 
    $scope.getAllVessels();

}]);