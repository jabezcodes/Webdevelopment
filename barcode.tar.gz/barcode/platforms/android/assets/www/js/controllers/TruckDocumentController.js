'use strict';
/* Controllers */

myApp.controller('TruckDocumentCtrl', ['$scope', '$location', '$http','$stateParams', '$sce','TruckDocumentService', 'TruckService','DocumentTypeService', 
    function($scope, $location, $http, $stateParams, $sce, TruckDocumentService ,TruckService,DocumentTypeService){

     $scope.showTruckDocumentList=true;
    $scope.showTruckDocumentForm=false;

    $scope.truckDocument = {};
    $scope.truckDocuments = {};  
    $scope.truck = {};
    $scope.trucks = {};  
    
    
    $scope.buttonTextTruckDocument = "";

    $scope.param1 = "";
    $scope.param2 = "";
    
    if( $stateParams.param2 != undefined){
        $scope.param2 = $stateParams.param2;
    }    

    if( $stateParams.param1 != undefined){
        $scope.param1 = $stateParams.param1;
    }

    $scope.currentPageTruckDocument = 1;
    $scope.pageSizeTruckDocument = 6;

    $scope.sortKeyTruckDocument = "";
    $scope.truckDocumentReverse = false; 

    $scope.sortTruckDocument = function(columnName,reverse){
        $scope.sortKeyTruckDocument = columnName;
        $scope.truckDocumentReverse = !$scope.truckDocumentReverse; 
    }


    $scope.getAllTruckDocuments= function(){
        TruckDocumentService.getAllTruckDocuments()
            .then(
                function( truckDocuments ) {
                    if(truckDocuments!=undefined){
                        $scope.truckDocuments = truckDocuments;    
                    }
                }
            );
    }
       
    $scope.setTruckDocument= function(id){
        TruckDocumentService.getTruckDocumentById(id)
            .then(
                function(truckDocument){
                    if(truckDocument!=undefined){
                        $scope.truckDocument=truckDocument;
                        $scope.param2=truckDocument.id;
                    }
                }
        );
    } 

    $scope.getAllTruckDocuments();

    $scope.getAllDocumentTypes= function(){
        DocumentTypeService.getAllDocumentTypes()
            .then(
                function( documentTypes ) {
                    if(documentTypes!=undefined){
                        $scope.documentTypes = documentTypes;    
                    }
                }
            );
    }
       
    $scope.setDocumentType= function(id){
        DocumentTypeService.getDocumentTypeById(id)
            .then(
                function(documentType){
                    if(documentType!=undefined){
                        $scope.documentType=documentType;
                        $scope.param2=documentType.id;
                    }
                }
        );
    } 

    $scope.getAllDocumentTypes();



     $scope.getAllTrucks= function(){
        TruckService.getAllTrucks()
            .then(
                function( trucks ) {
                    if(trucks!=undefined){
                        $scope.trucks = trucks;    
                    }
                }
            );
    }
       
    $scope.setTruck= function(id){
        TruckService.getTruckById(id)
            .then(
                function(truck){
                    if(truck!=undefined){
                        $scope.truck=truck;
                        $scope.param2=truck.id;
                    }
                }
        );
    } 

    $scope.getAllTrucks();
      
    $scope.loadTruckDocumentForm = function(truckDocument,isEdit){
        if (isEdit==1){
            $scope.buttonTextTruckDocument = "Update";
            $scope.truckDocument = truckDocument 
        }    
        else{
            $scope.buttonTextTruckDocument = "Add";
            $scope.truckDocument = {} ;
            $scope.truckDocument.truck = $scope.truck;

        }    
                   
        $scope.showTruckDocumentForm= true;
        $scope.showTruckDocumentList= false;
       }


    $scope.saveTruckDocument = function(truckDocument){
        if ($scope.buttonTextTruckDocument=="Add")
            TruckDocumentService.createTruckDocument(truckDocument)
                .then(
                    function( truckDocument ) {
                        if(truckDocument!=undefined){
                            $scope.truckDocument = {};
                            $scope.hideTruckDocumentForm();
                            $scope.getAllTruckDocuments();
                            alert("TruckDocument Added!");
                        }else{
                        }
                    }
                );
        else{
            TruckDocumentService.updateTruckDocument(truckDocument)
                .then(
                    function( truckDocument ) {
                        if(truckDocument!=undefined){
                            $scope.truckDocument = {};
                            $scope.hideTruckDocumentForm(); 
                            $scope.getAllTruckDocuments();
                            alert("TruckDocument Updated!");
                        }else{
                        }
                    }
                );
            }
    }

    $scope.hideTruckDocumentForm = function(){
        $scope.showTruckDocumentForm= false;
        $scope.showTruckDocumentList= true;
    }

    $scope.getAllTruckDocuments= function(){
        if( $scope.param1 != ""){if($scope.param1 =="Truck") {
            $scope.setTruck($scope.param2);
            TruckDocumentService.getAllTruckDocumentsByTruckId($scope.param2)
                 .then(
                    function( truckDocuments ) {
                        if(truckDocuments!=undefined){
                            $scope.truckDocuments = truckDocuments;                
                            }
                        }
                    );
        }
        }else{
            TruckDocumentService.getAllTruckDocuments()
                .then(
                    function( truckDocuments ) {
                        if(truckDocuments!=undefined){
                            $scope.truckDocuments = truckDocuments;
                            
                        }
                    }
                );
            }
        }    

    $scope.getAllTruckDocuments();



    /*$scope.loadTrip= function(consignmentTruckId){
        $location.url("#/app/Trip/ConsignmentTruck/" + consignmentTruckId)
    }*/

}]);