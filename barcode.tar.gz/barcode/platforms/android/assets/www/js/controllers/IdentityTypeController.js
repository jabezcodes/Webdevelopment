'use strict';
/* Controllers */

myApp.controller('IdentityTypeCtrl', ['$scope', '$location', '$http','$stateParams', '$sce','IdentityTypeService', 
    function($scope, $location, $http, $stateParams, $sce, IdentityTypeService ){

    $scope.showIdentityTypeList=true;
    $scope.showIdentityTypeForm=false;

    $scope.identityType = {};
    $scope.identityTypes = {};  

    $scope.buttonTextIdentityType = "";

    $scope.param1 = "";
    $scope.param2 = "";
    
    if( $stateParams.param2 != undefined){
        $scope.param2 = $stateParams.param2;
    }    

    if( $stateParams.param1 != undefined){
        $scope.param1 = $stateParams.param1;
    }

    $scope.currentPageIdentityType = 1;
    $scope.pageSizeIdentityType = 6;

    $scope.sortKeyIdentityType = "";
    $scope.identityTypeReverse = false; 

    $scope.sortIdentityType = function(columnName,reverse){
        $scope.sortKeyIdentityType = columnName;
        $scope.identityTypeReverse = !$scope.identityTypeReverse; 
    }

      
    $scope.loadIdentityTypeForm = function(identityType,isEdit){
        if (isEdit==1){
            $scope.buttonTextIdentityType = "Update";
            $scope.identityType = identityType 
        }    
        else{
            $scope.buttonTextIdentityType = "Add";
            $scope.identityType = {} ;

        }    
                   
        $scope.showIdentityTypeForm= true;
        $scope.showIdentityTypeList= false;
       }


    $scope.saveIdentityType = function(identityType){
        if ($scope.buttonTextIdentityType=="Add")
            IdentityTypeService.createIdentityType(identityType)
                .then(
                    function( identityType ) {
                        if(identityType!=undefined){
                            $scope.identityType = {};
                            $scope.hideIdentityTypeForm();
                            $scope.getAllIdentityTypes();
                            alert("IdentityType Added!");
                        }else{
                        }
                    }
                );
        else{
            IdentityTypeService.updateIdentityType(identityType)
                .then(
                    function( identityType ) {
                        if(identityType!=undefined){
                            $scope.identityType = {};
                            $scope.hideIdentityTypeForm(); 
                            $scope.getAllIdentityTypes();
                            alert("IdentityType Updated!");
                        }else{
                        }
                    }
                );
            }
    }

    $scope.hideIdentityTypeForm = function(){
        $scope.showIdentityTypeForm= false;
        $scope.showIdentityTypeList= true;
    }

    $scope.getAllIdentityTypes= function(){
        if( $scope.param1 != ""){
        }else{
            IdentityTypeService.getAllIdentityTypes()
                .then(
                    function( identityTypes ) {
                        if(identityTypes!=undefined){
                            $scope.identityTypes = identityTypes;
                            
                        }
                    }
                );
            }
        }    

    $scope.getAllIdentityTypes();
}]);