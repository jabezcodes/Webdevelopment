'use strict';
/* Controllers */

myApp.controller('TripCtrl', ['$scope', '$location', '$http','$stateParams', '$sce','TripService', 'GPSDeviceService', 'TripAssignStatusService', 'TripStatusService', 'GridDisplayService','ConsignmentTruckService',
    function($scope, $location, $http, $stateParams, $sce, TripService , GPSDeviceService, TripAssignStatusService, TripStatusService, GridDisplayService,ConsignmentTruckService){



    $scope.showTripList=true;
    $scope.showTripForm=false;
    $scope.showCreate = false;
    $scope.showNextButton = true;

    $scope.filePath =BASE_API + "Trip/GatePass/"

    $scope.trip = {};
    $scope.trips = {};  
    $scope.gPSDevices = {};
    $scope.gPSDevice = {};
    $scope.tripAssignStatuss = {};
    $scope.tripAssignStatus = {};
    $scope.tripStatuss = {};
    $scope.tripStatus = {};
    $scope.currentTrip = {};
        $scope.weights = {};
    $scope.weights.weight = 0;
    $scope.nextAction = {};

    $scope.consignmentTruck = {};

    $scope.buttonTextTrip = "";

    $scope.param1 = "";
    $scope.param2 = "";
    
    if( $stateParams.param2 != undefined){
        $scope.param2 = $stateParams.param2;
    }    

    if( $stateParams.param1 != undefined){
        $scope.param1 = $stateParams.param1;
    }

    $scope.currentPageTrip = 1;
    $scope.pageSizeTrip = 6;

    $scope.sortKeyTrip = "";
    $scope.tripReverse = false; 

    $scope.sortTrip = function(columnName,reverse){
        $scope.sortKeyTrip = columnName;
        $scope.tripReverse = !$scope.tripReverse; 
    }


    $scope.getAllGPSDevices= function(){
        GPSDeviceService.getAllGPSDevices()
            .then(
                function( gPSDevices ) {
                    if(gPSDevices!=undefined){
                        $scope.gPSDevices = gPSDevices;    
                    }
                }
            );
    }
       
    $scope.setGPSDevice= function(id){
        GPSDeviceService.getGPSDeviceById(id)
            .then(
                function(gPSDevice){
                    if(gPSDevice!=undefined){
                        $scope.gPSDevice=gPSDevice;
                        $scope.param2=gPSDevice.id;
                    }
                }
        );
    } 

    $scope.getAllGPSDevices();

    $scope.getAllTripAssignStatuss= function(){
        TripAssignStatusService.getAllTripAssignStatuss()
            .then(
                function( tripAssignStatuss ) {
                    if(tripAssignStatuss!=undefined){
                        $scope.tripAssignStatuss = tripAssignStatuss;    
                    }
                }
            );
    }
       
    $scope.setTripAssignStatus= function(id){
        TripAssignStatusService.getTripAssignStatusById(id)
            .then(
                function(tripAssignStatus){
                    if(tripAssignStatus!=undefined){
                        $scope.tripAssignStatus=tripAssignStatus;
                        $scope.param2=tripAssignStatus.id;
                    }
                }
        );
    } 

    $scope.getAllTripAssignStatuss();

    $scope.getAllTripStatuss= function(){
        TripStatusService.getAllTripStatuss()
            .then(
                function( tripStatuss ) {
                    if(tripStatuss!=undefined){
                        $scope.tripStatuss = tripStatuss;    
                    }
                }
            );
    }
       
    $scope.setTripStatus= function(id){
        TripStatusService.getTripStatusById(id)
            .then(
                function(tripStatus){
                    if(tripStatus!=undefined){
                        $scope.tripStatus=tripStatus;
                        $scope.param2=tripStatus.id;
                    }
                }
        );
    } 

    $scope.getAllTripStatuss();
      
    $scope.loadTripForm = function(trip,isEdit){
        if (isEdit==1){
            $scope.buttonTextTrip = "Update";
            $scope.trip = trip 
        }    
        else{
            $scope.buttonTextTrip = "Add";
            $scope.trip = {} ;

        }    
                   
        $scope.showTripForm= true;
        $scope.showTripList= false;
       }


    $scope.saveTrip = function(trip){
        if ($scope.buttonTextTrip=="Add")
            TripService.createTrip(trip)
                .then(
                    function( trip ) {
                        if(trip!=undefined){
                            $scope.trip = {};
                            $scope.hideTripForm();
                            $scope.getAllTrips();
                            alert("Trip Added!");
                        }else{
                        }
                    }
                );
        else{
            TripService.updateTrip(trip)
                .then(
                    function( trip ) {
                        if(trip!=undefined){
                            $scope.trip = {};
                            $scope.hideTripForm(); 
                            $scope.getAllTrips();
                            alert("Trip Updated!");
                        }else{
                        }
                    }
                );
            }
    }

    $scope.hideTripForm = function(){
        $scope.showTripForm= false;
        $scope.showTripList= true;
    }

    $scope.getAllTrips= function(){
        if( $scope.param1 != ""){if($scope.param1 =="GPSDevice") {
            $scope.setGPSDevice($scope.param2);
            TripService.getAllTripsByGPSDeviceId($scope.param2)
                 .then(
                    function( trips ) {
                        if(trips!=undefined){
                            $scope.trips = trips;                
                            }
                        }
                    );
        }if($scope.param1 =="TripAssignStatus") {
            $scope.setTripAssignStatus($scope.param2);
            TripService.getAllTripsByTripAssignStatusId($scope.param2)
                 .then(
                    function( trips ) {
                        if(trips!=undefined){
                            $scope.trips = trips;                
                            }
                        }
                    );
        }if($scope.param1 =="TripStatus") {
            $scope.setTripStatus($scope.param2);
            TripService.getAllTripsByTripStatusId($scope.param2)
                 .then(
                    function( trips ) {
                        if(trips!=undefined){
                            $scope.trips = trips;                
                            }
                        }
                    );
        }if($scope.param1 =="ConsignmentTruck") {
            $scope.setTripStatus($scope.param2);
            TripService.getAllTripsByConsignmentTruckId($scope.param2)
                 .then(
                    function( trips ) {
                        if(trips!=undefined){
                            $scope.trips = trips;                
                            }
                        }
                    );
        }
        }else{
            TripService.getAllTrips()
                .then(
                    function( trips ) {
                        if(trips!=undefined){
                            $scope.trips = trips;
                            
                        }
                    }
                );
            }
        }    

    //$scope.getAllTrips();


        $scope.setConsignmentTruck = function(){
            ConsignmentTruckService.getConsignmentTruckById($scope.param2)
            .then(
                function(consignmentTruck){
                    if(consignmentTruck!=undefined){
                        $scope.consignmentTruck=consignmentTruck;
                    }
                }
            );
        }

        
        $scope.getCurrentTrip = function(){//Add params
            //$scope.clearConsignmentTruckWorkSpace();
            GridDisplayService.getGridDisplayByTag("CurrentTrip", $scope.param2)//replace with Params
             .then(
                function( currentTrip ) {
                    if(currentTrip!=undefined){
                        console.log(currentTrip);
                        $scope.setCurrentTrip(currentTrip.content[0]);
                    }
                }
            );
        } 

        $scope.setTripInTransit = function(tripInTransit){
            $scope.tripInTransit = tripInTransit;
        }

        $scope.getTripInTransit = function(){//Add params
            //$scope.clearConsignmentTruckWorkSpace();
            GridDisplayService.getGridDisplayByTag("TripInTransit", $scope.param2)//replace with Params
             .then(
                function( tripInTransit ) {
                    if(tripInTransit!=undefined){
                        console.log(tripInTransit);
                        $scope.setTripInTransit(tripInTransit.content[0]);
                    }
                }
            );
        } 


         $scope.setCurrentTrip = function(currentTrip){
            $scope.currentTrip = currentTrip;
            if(currentTrip == undefined)
                    $scope.showCreate=true
            if(currentTrip!=undefined){
                if(currentTrip.isDeliveryComplete== true){
                    $scope.showCreate=true
                 }else{   
                     TripService.getNextAction(currentTrip.id)
                             .then(
                                function( nextAction ) {
                                    console.log(nextAction);
                                    $scope.setNextAction(nextAction);
                                    if(nextAction.showWeight==true)
                                        $scope.showNextButton = false;
                                    if(currentTrip.isDeliveryComplete== true)
                                        $scope.showCreate=true
                                }
                            );
                }
            
            }else{
                $scope.getCanCreate();
            }
        }

    $scope.create=function(){
            TripService.create($scope.param2)
            .then(
                function( trip ) {
                    if(trip!=undefined){
                        $scope.setCurrentTrip(trip);
                        $scope.showCreate=false;
                    }
                }
            );
    }

    $scope.setNextAction=function(nextAction){
        $scope.nextAction= nextAction;
    }
        
    $scope.getCanCreate = function(){
        TripService.getCanCreate()
            .then(
                function( nextAction ) {
                    if(nextAction==true){
                        if($scope.currentTrip==undefined)
                        $scope.showCreate=true;
                    }
                }
            );
    }

    $scope.performNextAction = function(tripId){
        $scope.showNextActionButton=false;
        TripService.performNextAction(tripId,$scope.weights.weight,$scope.param2,$scope.weights.weight)
            .then(
                function( trip ) {
                    if(trip!=undefined){
                        $scope.setCurrentTrip(trip);
                        $scope.weights.weight = 0;
                        $scope.showNextActionButton=true;
                    }
                }
            );

    }

    $scope.setShowNextButton=function(){
        if($scope.weights.weight!=0 )
            $scope.showNextButton = true;
    }

        $scope.setConsignmentTruck();
        $scope.getCurrentTrip();
        $scope.getTripInTransit();







}]);