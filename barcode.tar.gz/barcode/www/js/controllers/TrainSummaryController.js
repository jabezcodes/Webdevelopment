'use strict';
/* Controllers */

myApp.controller('TrainSummaryCtrl', ['$scope', '$interval', '$location', '$http','$stateParams', '$sce','ConsignmentService', 
    function($scope, $interval, $location, $http, $stateParams, $sce, ConsignmentService ){
     $scope.summary = {};

     $scope.value1=0;
     $scope.value2=0;
     $scope.recd=0;


       $scope.options1 = {
        animate : { enabled: true, duration: 1000, ease: 'bounce' },
        unit:'%',
        min: 0,
        max: 100,
        readOnly: true,
        size: 150,
        subText: {
          enabled: true,
          text: 'Received',
          color: 'gray',
          font: 'auto'
        },
        trackWidth: 40,
        barWidth: 25,
        trackColor: '#ffffff',
        barColor: '#a4232d',
        dynamicOptions: true
      };

       $scope.options2 = {
        animate : { enabled: true, duration: 1000, ease: 'bounce' },
        unit:'%',
        min: 0,
        max: 110,
        readOnly: true,
        size: 150,
        subText: {
          enabled: true,
          text: 'Delivered',
          color: 'gray',
          font: 'auto'
        },
        trackWidth: 40,
        barWidth: 25,
        trackColor: '#ffffff',
        barColor: '#a4232d',
        dynamicOptions: true
      };
     
      $scope.getConsignmentSummary = function(){
        ConsignmentService.getTrainSummary(3)
          .then(
              function( summary ) {
                if(summary!=undefined){
                    console.log(summary);
                    $scope.summary =summary;
                    //$scope.value1= ($scope.summary.rakeListReceivedTonnage/$scope.summary.rakeListTonnage)*100;
                    //$scope.value2= ($scope.summary.deliveredTonnage/$scope.summary.rakeListTonnage)*100;
                    //$scope.value1= 20;
                    //$scope.value2= 20;
                }
              }
          );
        }


    $scope.getConsignmentSummary();

    var flag =true;

    $scope.callAtInterval = function() {
      
        if(flag){
          //alert("ddf");
          
          $scope.value1 = ($scope.summary.rakeListReceivedTonnage/$scope.summary.rakeListTonnage)*100;
          $scope.value2 = ($scope.summary.deliveredTonnage/$scope.summary.rakeListTonnage)*100;
          flag = false;
          console.log(summary);
        } 
        else {
          //alert("false");
          
          $scope.value1 = 0;
          $scope.value2 = 0
          flag = true;
        }
    }

    
    $interval( function(){ $scope.callAtInterval(); }, 1000);
    //$interval( function(){ $scope.callAtInterval2(); }, 1000);

    $scope.getConsignmentById= function(){
                ConsignmentService.getConsignmentById(3)
                    .then(
                        function( consignment ) {
                            if(consignment!=undefined){
                                $scope.consignment = consignment;
                                
                            }
                        }
                    );
                }
                

        $scope.getConsignmentById();


}]);
