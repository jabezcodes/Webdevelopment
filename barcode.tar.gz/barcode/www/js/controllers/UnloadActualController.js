'use strict';
/* Controllers */

myApp.controller('UnloadActualCtrl', ['$scope', '$location', '$http','$stateParams', '$sce','UnloadActualService', 'UnloadPlanService', 
    function($scope, $location, $http, $stateParams, $sce, UnloadActualService , UnloadPlanService){

    $scope.showUnloadActualList=true;
    $scope.showUnloadActualForm=false;

    $scope.unloadActual = {};
    $scope.unloadActuals = {};  
    $scope.unloadPlans = {};
    $scope.unloadPlan = {};

    $scope.buttonTextUnloadActual = "";

    $scope.param1 = "";
    $scope.param2 = "";
    
    if( $stateParams.param2 != undefined){
        $scope.param2 = $stateParams.param2;
    }    

    if( $stateParams.param1 != undefined){
        $scope.param1 = $stateParams.param1;

    }
    
    $scope.currentPageUnloadActual = 1;
    $scope.pageSizeUnloadActual = 6;

    $scope.sortKeyUnloadActual = "";
    $scope.unloadActualReverse = false; 

    $scope.sortUnloadActual = function(columnName,reverse){
        $scope.sortKeyUnloadActual = columnName;
        $scope.unloadActualReverse = !$scope.unloadActualReverse; 
    }


    $scope.getAllUnloadPlans= function(){
        UnloadPlanService.getAllUnloadPlans()
            .then(
                function( unloadPlans ) {
                    if(unloadPlans!=undefined){
                        $scope.unloadPlans = unloadPlans;    
                    }
                }
            );
    }
       
    $scope.setUnloadPlan= function(id){

        UnloadPlanService.getUnloadPlanById(id)
            .then(
                function(unloadPlan){
                    if(unloadPlan!=undefined){
                        $scope.unloadPlan=unloadPlan;
                        $scope.param2=unloadPlan.id;
                    }
                }
        );
    } 

    $scope.getAllUnloadPlans();
      
    $scope.loadUnloadActualForm = function(unloadActual,isEdit){
        if (isEdit==1){
            $scope.buttonTextUnloadActual = "Update";
            $scope.unloadActual = unloadActual 
        }    
        else{
            $scope.buttonTextUnloadActual = "Add";
            $scope.unloadActual = {} ;
            $scope.unloadActual.unloadPlan = $scope.unloadPlan;

        }    
                   
        $scope.showUnloadActualForm= true;
        $scope.showUnloadActualList= false;
       }


    $scope.saveUnloadActual = function(unloadActual){
        if ($scope.buttonTextUnloadActual=="Add")
            UnloadActualService.createUnloadActual(unloadActual)
                .then(
                    function( unloadActual ) {
                        if(unloadActual!=undefined){
                            $scope.unloadActual = {};
                            $scope.hideUnloadActualForm();
                            $scope.getAllUnloadActuals();
                            alert("UnloadActual Added!");
                        }else{
                        }
                    }
                );
        else{
            UnloadActualService.updateUnloadActual(unloadActual)
                .then(
                    function( unloadActual ) {
                        if(unloadActual!=undefined){
                            $scope.unloadActual = {};
                            $scope.hideUnloadActualForm(); 
                            $scope.getAllUnloadActuals();
                            alert("UnloadActual Updated!");
                        }else{
                        }
                    }
                );
            }
    }

    $scope.hideUnloadActualForm = function(){
        $scope.showUnloadActualForm= false;
        $scope.showUnloadActualList= true;
    }

    $scope.getAllUnloadActuals= function(){
        if( $scope.param1 != ""){if($scope.param1 =="UnloadPlan") {
            $scope.setUnloadPlan($scope.param2);
            UnloadActualService.getAllUnloadActualsByUnloadPlanId($scope.param2)
                 .then(
                    function( unloadActuals ) {
                        if(unloadActuals!=undefined){
                            $scope.unloadActuals = unloadActuals;                
                            }
                        }
                    );
        }
        }else{
            UnloadActualService.getAllUnloadActuals()
                .then(
                    function( unloadActuals ) {
                        if(unloadActuals!=undefined){
                            $scope.unloadActuals = unloadActuals;
                            
                        }
                    }
                );
            }
        }    

    $scope.getAllUnloadActuals();
}]);