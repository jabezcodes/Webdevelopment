'use strict';
/* Controllers */

myApp.controller('UnloadPlanCtrl', ['$scope', '$location', '$http','$stateParams', '$sce','UnloadPlanService', 'VesselHoldService', 'ConsignmentService', 
    function($scope, $location, $http, $stateParams, $sce, UnloadPlanService , VesselHoldService, ConsignmentService){

    $scope.showUnloadPlanList=true;
    $scope.showUnloadPlanForm=false;

    $scope.unloadPlan = {};
    $scope.unloadPlans = {};  
    $scope.vesselHolds = {};
    $scope.vesselHold = {};
    $scope.consignments = {};
    $scope.consignment = {};

    $scope.buttonTextUnloadPlan = "";

    $scope.param1 = "";
    $scope.param2 = "";
    
    if( $stateParams.param2 != undefined){
        $scope.param2 = $stateParams.param2;
    }    

    if( $stateParams.param1 != undefined){
        $scope.param1 = $stateParams.param1;
    }

    $scope.currentPageUnloadPlan = 1;
    $scope.pageSizeUnloadPlan = 6;

    $scope.sortKeyUnloadPlan = "";
    $scope.unloadPlanReverse = false; 

    $scope.sortUnloadPlan = function(columnName,reverse){
        $scope.sortKeyUnloadPlan = columnName;
        $scope.unloadPlanReverse = !$scope.unloadPlanReverse; 
    }


    $scope.getAllVesselHolds= function(){
        VesselHoldService.getAllVesselHolds()
            .then(
                function( vesselHolds ) {
                    if(vesselHolds!=undefined){
                        $scope.vesselHolds = vesselHolds;    
                    }
                }
            );
    }
       
    $scope.setVesselHold= function(id){
        VesselHoldService.getVesselHoldById(id)
            .then(
                function(vesselHold){
                    if(vesselHold!=undefined){
                        $scope.vesselHold=vesselHold;
                        $scope.param2=vesselHold.id;
                    }
                }
        );
    } 

    $scope.getAllVesselHolds();

    $scope.getAllConsignments= function(){
        ConsignmentService.getAllConsignments()
            .then(
                function( consignments ) {
                    if(consignments!=undefined){
                        $scope.consignments = consignments;    
                    }
                }
            );
    }
       
    $scope.setConsignment= function(id){
        ConsignmentService.getConsignmentById(id)
            .then(
                function(consignment){
                    if(consignment!=undefined){
                        $scope.consignment=consignment;
                        $scope.param2=consignment.id;
                    }
                }
        );
    } 

    $scope.getAllConsignments();
      
    $scope.loadUnloadPlanForm = function(unloadPlan,isEdit){
        if (isEdit==1){
            $scope.buttonTextUnloadPlan = "Update";
            $scope.unloadPlan = unloadPlan 
        }    
        else{
            $scope.buttonTextUnloadPlan = "Add";
            $scope.unloadPlan = {} ;

        }    
                   
        $scope.showUnloadPlanForm= true;
        $scope.showUnloadPlanList= false;
       }


    $scope.saveUnloadPlan = function(unloadPlan){
        if ($scope.buttonTextUnloadPlan=="Add")
            UnloadPlanService.createUnloadPlan(unloadPlan)
                .then(
                    function( unloadPlan ) {
                        if(unloadPlan!=undefined){
                            $scope.unloadPlan = {};
                            $scope.hideUnloadPlanForm();
                            $scope.getAllUnloadPlans();
                            alert("UnloadPlan Added!");
                        }else{
                        }
                    }
                );
        else{
            UnloadPlanService.updateUnloadPlan(unloadPlan)
                .then(
                    function( unloadPlan ) {
                        if(unloadPlan!=undefined){
                            $scope.unloadPlan = {};
                            $scope.hideUnloadPlanForm(); 
                            $scope.getAllUnloadPlans();
                            alert("UnloadPlan Updated!");
                        }else{
                        }
                    }
                );
            }
    }

    $scope.hideUnloadPlanForm = function(){
        $scope.showUnloadPlanForm= false;
        $scope.showUnloadPlanList= true;
    }

    $scope.getAllUnloadPlans= function(){
        if( $scope.param1 != ""){if($scope.param1 =="VeselHold") {
            $scope.setVesselHold($scope.param2);
            UnloadPlanService.getAllUnloadPlansByVeselHoldId($scope.param2)
                 .then(
                    function( unloadPlans ) {
                        if(unloadPlans!=undefined){
                            $scope.unloadPlans = unloadPlans;                
                            }
                        }
                    );
        }if($scope.param1 =="Consignment") {
            $scope.setConsignment($scope.param2);
            UnloadPlanService.getAllUnloadPlansByConsignmentId($scope.param2)
                 .then(
                    function( unloadPlans ) {
                        if(unloadPlans!=undefined){
                            $scope.unloadPlans = unloadPlans;                
                            }
                        }
                    );
        }
        }else{
            UnloadPlanService.getAllUnloadPlans()
                .then(
                    function( unloadPlans ) {
                        if(unloadPlans!=undefined){
                            $scope.unloadPlans = unloadPlans;
                            
                        }
                    }
                );
            }
        }    

    $scope.getAllUnloadPlans();

    $scope.getActuals=function(unloadPlan){
        $location.url("#/app/UnloadActual");

    }
}]);