'use strict';
/* Controllers */

myApp.controller('VesselCtrl', ['$scope', '$location', '$http','$stateParams', '$sce','VesselService', 'ConsignmentService', 
    function($scope, $location, $http, $stateParams, $sce, VesselService , ConsignmentService){

    $scope.showVesselList=true;
    $scope.showVesselForm=false;

    $scope.vessel = {};
    $scope.vessels = {};  
    $scope.consignments = {};
    $scope.consignment = {};

    $scope.buttonTextVessel = "";

    $scope.param1 = "";
    $scope.param2 = "";
    
    if( $stateParams.param2 != undefined){
        $scope.param2 = $stateParams.param2;
    }    

    if( $stateParams.param1 != undefined){
        $scope.param1 = $stateParams.param1;
    }

    $scope.currentPageVessel = 1;
    $scope.pageSizeVessel = 6;

    $scope.sortKeyVessel = "";
    $scope.vesselReverse = false; 

    $scope.sortVessel = function(columnName,reverse){
        $scope.sortKeyVessel = columnName;
        $scope.vesselReverse = !$scope.vesselReverse; 
    }


    $scope.getAllConsignments= function(){
        ConsignmentService.getAllConsignments()
            .then(
                function( consignments ) {
                    if(consignments!=undefined){
                        $scope.consignments = consignments;    
                    }
                }
            );
    }
       
    $scope.setConsignment= function(id){
        ConsignmentService.getConsignmentById(id)
            .then(
                function(consignment){
                    if(consignment!=undefined){
                        $scope.consignment=consignment;
                        $scope.param2=consignment.id;
                    }
                }
        );
    } 

    $scope.getAllConsignments();
      
    $scope.loadVesselForm = function(vessel,isEdit){
        if (isEdit==1){
            $scope.buttonTextVessel = "Update";
            $scope.vessel = vessel 
        }    
        else{
            $scope.buttonTextVessel = "Add";
            $scope.vessel = {} ;

        }    
                   
        $scope.showVesselForm= true;
        $scope.showVesselList= false;
       }


    $scope.saveVessel = function(vessel){
        if ($scope.buttonTextVessel=="Add")
            VesselService.createVessel(vessel)
                .then(
                    function( vessel ) {
                        if(vessel!=undefined){
                            $scope.vessel = {};
                            $scope.hideVesselForm();
                            $scope.getAllVessels();
                            alert("Vessel Added!");
                        }else{
                        }
                    }
                );
        else{
            VesselService.updateVessel(vessel)
                .then(
                    function( vessel ) {
                        if(vessel!=undefined){
                            $scope.vessel = {};
                            $scope.hideVesselForm(); 
                            $scope.getAllVessels();
                            alert("Vessel Updated!");
                        }else{
                        }
                    }
                );
            }
    }

    $scope.hideVesselForm = function(){
        $scope.showVesselForm= false;
        $scope.showVesselList= true;
    }

    $scope.getAllVessels= function(){
        if( $scope.param1 != ""){if($scope.param1 =="Consignment") {
            $scope.setConsignment($scope.param2);
            VesselService.getAllVesselsByConsignmentId($scope.param2)
                 .then(
                    function( vessels ) {
                        if(vessels!=undefined){
                            $scope.vessels = vessels;                
                            }
                        }
                    );
        }
        }else{
            VesselService.getAllVessels()
                .then(
                    function( vessels ) {
                        if(vessels!=undefined){
                            $scope.vessels = vessels;
                            
                        }
                    }
                );
            }
        }    

    $scope.getAllVessels();
}]);