'use strict';
/* Controllers */


myApp.controller('AppCtrl', ['$scope', '$http', '$cookies', '$rootScope', '$httpParamSerializer', '$location', 'LoginService','$localStorage', 
    function($scope, $http,  $cookies ,$rootScope, $httpParamSerializer,$location, LoginService, $localStorage){

  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  // Form data for the login modal
  $scope.loginData = {};
  $scope.user = {};
  $scope.user.login = "R@360";
  $scope.user.password = "1";

  // Triggered in the login modal to close it
  $scope.closeLogin = function() {
    $scope.modal.hide();
  };

  $scope.data = {
          grant_type:"password", 
          username: "", 
          password: "", 
          client_id: "clientapp"
      };
  $scope.encoded = btoa("clientapp:123456");


    $scope.login = function(){
    $scope.data.username = $scope.user.login;
    $scope.data.password = $scope.user.password;

    var req = {
            method: 'POST',
            crossOrigin: true,
            url: "http://192.169.233.39:8080/oauth/token",
            headers: {
                "Authorization": "Basic " + $scope.encoded,
                "Content-type": "application/x-www-form-urlencoded; charset=utf-8"
            },
            data: $httpParamSerializer($scope.data)
        }

        $http(req).then(function(data){
          console.log(data);
            $http.defaults.headers.common.Authorization = 
              'Bearer ' + data.data.access_token;
            $cookies.put("access_token", data.data.access_token);
            console.log( $cookies.get("access_token"));
            $location.url("/app/Summary");

            //window.location.href="index";
        });   
}
}]);