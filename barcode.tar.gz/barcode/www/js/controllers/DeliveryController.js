'use strict';
/* Controllers */

myApp.controller('DeliveryCtrl', ['$scope', '$location', '$http','$stateParams', '$sce','DeliveryService', 'TripService', 
    function($scope, $location, $http, $stateParams, $sce, DeliveryService , TripService){

    $scope.showDeliveryList=true;
    $scope.showDeliveryForm=false;

    $scope.delivery = {};
    $scope.deliverys = {};  
    $scope.trips = {};
    $scope.trip = {};

    $scope.buttonTextDelivery = "";

    $scope.param1 = "";
    $scope.param2 = "";
    
    if( $stateParams.param2 != undefined){
        $scope.param2 = $stateParams.param2;
    }    

    if( $stateParams.param1 != undefined){
        $scope.param1 = $stateParams.param1;
    }

    $scope.currentPageDelivery = 1;
    $scope.pageSizeDelivery = 6;

    $scope.sortKeyDelivery = "";
    $scope.deliveryReverse = false; 

    $scope.sortDelivery = function(columnName,reverse){
        $scope.sortKeyDelivery = columnName;
        $scope.deliveryReverse = !$scope.deliveryReverse; 
    }


    $scope.getAllTrips= function(){
        TripService.getAllTrips()
            .then(
                function( trips ) {
                    if(trips!=undefined){
                        $scope.trips = trips;    
                    }
                }
            );
    }
       
    $scope.setTrip= function(id){
        TripService.getTripById(id)
            .then(
                function(trip){
                    if(trip!=undefined){
                        $scope.trip=trip;
                        $scope.param2=trip.id;
                    }
                }
        );
    } 

    $scope.getAllTrips();
      
    $scope.loadDeliveryForm = function(delivery,isEdit){
        if (isEdit==1){
            $scope.buttonTextDelivery = "Update";
            $scope.delivery = delivery 
        }    
        else{
            $scope.buttonTextDelivery = "Add";
            $scope.delivery = {} ;

        }    
                   
        $scope.showDeliveryForm= true;
        $scope.showDeliveryList= false;
       }


    $scope.saveDelivery = function(delivery){
        if ($scope.buttonTextDelivery=="Add")
            DeliveryService.createDelivery(delivery)
                .then(
                    function( delivery ) {
                        if(delivery!=undefined){
                            $scope.delivery = {};
                            $scope.hideDeliveryForm();
                            $scope.getAllDeliverys();
                            alert("Delivery Added!");
                        }else{
                        }
                    }
                );
        else{
            DeliveryService.updateDelivery(delivery)
                .then(
                    function( delivery ) {
                        if(delivery!=undefined){
                            $scope.delivery = {};
                            $scope.hideDeliveryForm(); 
                            $scope.getAllDeliverys();
                            alert("Delivery Updated!");
                        }else{
                        }
                    }
                );
            }
    }

    $scope.hideDeliveryForm = function(){
        $scope.showDeliveryForm= false;
        $scope.showDeliveryList= true;
    }

    $scope.getAllDeliverys= function(){
        if( $scope.param1 != ""){if($scope.param1 =="Trip") {
            $scope.setTrip($scope.param2);
            DeliveryService.getAllDeliverysByTripId($scope.param2)
                 .then(
                    function( deliverys ) {
                        if(deliverys!=undefined){
                            $scope.deliverys = deliverys;                
                            }
                        }
                    );
        }
        }else{
            DeliveryService.getAllDeliverys()
                .then(
                    function( deliverys ) {
                        if(deliverys!=undefined){
                            $scope.deliverys = deliverys;
                            
                        }
                    }
                );
            }
        }    

    $scope.getAllDeliverys();
}]);