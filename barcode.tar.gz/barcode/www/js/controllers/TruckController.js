'use strict';
/* Controllers */

myApp.controller('TruckCtrl', ['$scope', '$location', '$http','$stateParams', '$sce','TruckService','GridDisplayService','ImageService', 
    function($scope, $location, $http, $stateParams, $sce, TruckService ,GridDisplayService,ImageService){

   $scope.showTruckList=true;
    $scope.showTruckForm=false;

    $scope.truck = {};
    $scope.trucks = {};  
    
    $scope.buttonTextTruck = "";

    $scope.param1 = "";
    $scope.param2 = "";
    
    if( $stateParams.param2 != undefined){
        $scope.param2 = $stateParams.param2;
    }    

    if( $stateParams.param1 != undefined){
        $scope.param1 = $stateParams.param1;
    }

    $scope.currentPageTruck = 1;
    $scope.pageSizeTruck = 6;

    $scope.sortKeyTruck = "";
    $scope.truckReverse = false; 

    $scope.sortTruck = function(columnName,reverse){
        $scope.sortKeyTruck = columnName;
        $scope.truckReverse = !$scope.truckReverse; 
    }


    $scope.getAllTrucks= function(){
        TruckService.getAllTrucks()
            .then(
                function( trucks ) {
                    if(trucks!=undefined){
                        $scope.trucks = trucks;    
                    }
                }
            );
    }
       
    $scope.setTruck= function(id){
        TruckService.getTruckById(id)
            .then(
                function(truck){
                    if(truck!=undefined){
                        $scope.truck=truck;
                        $scope.param2=truck.id;
                    }
                }
        );
    } 

    $scope.getAllTrucks();
      
    $scope.loadTruckForm = function(truck,isEdit){
        if (isEdit==1){
            $scope.buttonTextTruck = "Update";
            $scope.truck = truck 
        }    
        else{
            $scope.buttonTextTruck = "Add";
            $scope.truck = {} ;

        }    
                   
        $scope.showTruckForm= true;
        $scope.showTruckList= false;
       }


    $scope.saveTruck = function(truck){
        if ($scope.buttonTextTruck=="Add")
            TruckService.createTruck(truck)
                .then(
                    function( truck ) {
                        if(truck!=undefined){
                            $scope.truck = {};
                            $scope.hideTruckForm();
                            $scope.getAllTrucks();
                            alert("Truck Added!");
                        }else{
                        }
                    }
                );
        else{
            TruckService.updateTruck(truck)
                .then(
                    function( truck ) {
                        if(truck!=undefined){
                            $scope.truck = {};
                            $scope.hideTruckForm(); 
                            $scope.getAllTrucks();
                            alert("Truck Updated!");
                        }else{
                        }
                    }
                );
            }
    }

    $scope.hideTruckForm = function(){
        $scope.showTruckForm= false;
        $scope.showTruckList= true;
    }

    $scope.getAllTrucks= function(){
            TruckService.getAllTrucks()
                .then(
                    function( trucks ) {
                        if(trucks!=undefined){
                            $scope.trucks = trucks;
                            
                        }
                    }
                );
            }
            
    
   
    $scope.getAllTrucks();



    /*$scope.loadTrip= function(consignmentTruckId){
        $location.url("#/app/Trip/ConsignmentTruck/" + consignmentTruckId)
    }*/

}]);