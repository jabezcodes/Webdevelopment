'use strict';
/* Controllers */

myApp.controller('PersonCtrl', ['$scope', '$location', '$http','$stateParams', '$sce','PersonService', 
    function($scope, $location, $http, $stateParams, $sce, PersonService ){

    $scope.showPersonList=true;
    $scope.showPersonForm=false;

    $scope.person = {};
    $scope.persons = {};  

    $scope.buttonTextPerson = "";

    $scope.param1 = "";
    $scope.param2 = "";
    
    if( $stateParams.param2 != undefined){
        $scope.param2 = $stateParams.param2;
    }    

    if( $stateParams.param1 != undefined){
        $scope.param1 = $stateParams.param1;
    }

    $scope.currentPagePerson = 1;
    $scope.pageSizePerson = 6;

    $scope.sortKeyPerson = "";
    $scope.personReverse = false; 

    $scope.sortPerson = function(columnName,reverse){
        $scope.sortKeyPerson = columnName;
        $scope.personReverse = !$scope.personReverse; 
    }

      
    $scope.loadPersonForm = function(person,isEdit){
        if (isEdit==1){
            $scope.buttonTextPerson = "Update";
            $scope.person = person 
        }    
        else{
            $scope.buttonTextPerson = "Add";
            $scope.person = {} ;

        }    
                   
        $scope.showPersonForm= true;
        $scope.showPersonList= false;
       }


    $scope.savePerson = function(person){
        if ($scope.buttonTextPerson=="Add")
            PersonService.createPerson(person)
                .then(
                    function( person ) {
                        if(person!=undefined){
                            $scope.person = {};
                            $scope.hidePersonForm();
                            $scope.getAllPersons();
                            alert("Person Added!");
                        }else{
                        }
                    }
                );
        else{
            PersonService.updatePerson(person)
                .then(
                    function( person ) {
                        if(person!=undefined){
                            $scope.person = {};
                            $scope.hidePersonForm(); 
                            $scope.getAllPersons();
                            alert("Person Updated!");
                        }else{
                        }
                    }
                );
            }
    }

    $scope.hidePersonForm = function(){
        $scope.showPersonForm= false;
        $scope.showPersonList= true;
    }

    $scope.getAllPersons= function(){
        if( $scope.param1 != ""){
        }else{
            PersonService.getAllPersons()
                .then(
                    function( persons ) {
                        if(persons!=undefined){
                            $scope.persons = persons;
                            
                        }
                    }
                );
            }
        }    

    $scope.getAllPersons();
}]);