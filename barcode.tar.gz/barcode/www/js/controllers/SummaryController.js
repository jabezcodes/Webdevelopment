'use strict';
/* Controllers */

myApp.controller('SummaryCtrl', ['$scope', '$location', '$http','$stateParams', '$sce','ConsignmentService', 
    function($scope, $location, $http, $stateParams, $sce, ConsignmentService ){
     $scope.summary = {};
     
      $scope.getConsignmentSummary = function(){
        ConsignmentService.getTrainSummary(4)
          .then(
              function( summary ) {
                if(summary!=undefined){
                    $scope.summary =summary;
                    $scope.setShowConsignmentSummary(true);
                }
              }
          );
        }


    $scope.getConsignmentSummary();


 


}]);