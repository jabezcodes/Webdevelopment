'use strict';
/* Controllers */

myApp.controller('VesselHoldCtrl', ['$scope', '$location', '$http','$stateParams', '$sce','VesselHoldService', 'ConsignmentService', 
    function($scope, $location, $http, $stateParams, $sce, VesselHoldService , ConsignmentService){

    $scope.showVesselHoldList=true;
    $scope.showVesselHoldForm=false;

    $scope.vesselHold = {};
    $scope.vesselHolds = {};  
    $scope.consignments = {};
    $scope.consignment = {};

    $scope.buttonTextVesselHold = "";

    $scope.param1 = "";
    $scope.param2 = "";
    
    if( $stateParams.param2 != undefined){
        $scope.param2 = $stateParams.param2;
    }    

    if( $stateParams.param1 != undefined){
        $scope.param1 = $stateParams.param1;
    }

    $scope.currentPageVesselHold = 1;
    $scope.pageSizeVesselHold = 6;

    $scope.sortKeyVesselHold = "";
    $scope.vesselHoldReverse = false; 

    $scope.sortVesselHold = function(columnName,reverse){
        $scope.sortKeyVesselHold = columnName;
        $scope.vesselHoldReverse = !$scope.vesselHoldReverse; 
    }


    $scope.getAllConsignments= function(){
        ConsignmentService.getAllConsignments()
            .then(
                function( consignments ) {
                    if(consignments!=undefined){
                        $scope.consignments = consignments;    
                    }
                }
            );
    }
       
    $scope.setConsignment= function(id){
        ConsignmentService.getConsignmentById(id)
            .then(
                function(consignment){
                    if(consignment!=undefined){
                        $scope.consignment=consignment;
                        $scope.param2=consignment.id;
                    }
                }
        );
    } 

    $scope.getAllConsignments();
      
    $scope.loadVesselHoldForm = function(vesselHold,isEdit){
        if (isEdit==1){
            $scope.buttonTextVesselHold = "Update";
            $scope.vesselHold = vesselHold 
        }    
        else{
            $scope.buttonTextVesselHold = "Add";
            $scope.vesselHold = {} ;

        }    
                   
        $scope.showVesselHoldForm= true;
        $scope.showVesselHoldList= false;
       }


    $scope.saveVesselHold = function(vesselHold){
        if ($scope.buttonTextVesselHold=="Add")
            VesselHoldService.createVesselHold(vesselHold)
                .then(
                    function( vesselHold ) {
                        if(vesselHold!=undefined){
                            $scope.vesselHold = {};
                            $scope.hideVesselHoldForm();
                            $scope.getAllVesselHolds();
                            alert("VesselHold Added!");
                        }else{
                        }
                    }
                );
        else{
            VesselHoldService.updateVesselHold(vesselHold)
                .then(
                    function( vesselHold ) {
                        if(vesselHold!=undefined){
                            $scope.vesselHold = {};
                            $scope.hideVesselHoldForm(); 
                            $scope.getAllVesselHolds();
                            alert("VesselHold Updated!");
                        }else{
                        }
                    }
                );
            }
    }

    $scope.hideVesselHoldForm = function(){
        $scope.showVesselHoldForm= false;
        $scope.showVesselHoldList= true;
    }

    $scope.getAllVesselHolds= function(){
        if( $scope.param1 != ""){if($scope.param1 =="Consignment") {
            $scope.setConsignment($scope.param2);
            VesselHoldService.getAllVesselHoldsByConsignmentId($scope.param2)
                 .then(
                    function( vesselHolds ) {
                        if(vesselHolds!=undefined){
                            $scope.vesselHolds = vesselHolds;                
                            }
                        }
                    );
        }
        }else{
            VesselHoldService.getAllVesselHolds()
                .then(
                    function( vesselHolds ) {
                        if(vesselHolds!=undefined){
                            $scope.vesselHolds = vesselHolds;
                            
                        }
                    }
                );
            }
        }    

    $scope.getAllVesselHolds();
}]);