'use strict';
var DELIVERY_URI = "Delivery"
var TRIP_URI = "Trip"

services.factory('DeliveryService', function ($http, $q ) {
    // Return public API.
    return({
        createDelivery:createDelivery,
        updateDelivery:updateDelivery,
        getAllDeliverys:getAllDeliverys,        getAllDeliverysByTripId:getAllDeliverysByTripId,
        getDeliveryById: getDeliveryById
    });

    function createDelivery( delivery ) {
        var request = $http({
            method: "post",
            crossDomain:true,
            url:  BASE_API + DELIVERY_URI,
            data:delivery
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function updateDelivery( delivery ) {
        var request = $http({
            method: "put",
            crossDomain:true,
            url:  BASE_API + DELIVERY_URI,
            data:delivery
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getDeliveryById(deliveryId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + DELIVERY_URI+ "/" +deliveryId
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getAllDeliverys(){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API +  DELIVERY_URI 
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getAllDeliverysByTripId(tripId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + DELIVERY_URI+ "/" +TRIP_URI+ "/" +tripId 
        });
        return( request.then( handleSuccess, handleError ) );
    }
  
});