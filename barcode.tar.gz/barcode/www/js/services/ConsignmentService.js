'use strict';
var CONSIGNMENT_URI = "Consignment"

services.factory('ConsignmentService', function ($http, $q ) {
    // Return public API.
    return({
        createConsignment:createConsignment,
        updateConsignment:updateConsignment,
        getAllConsignments:getAllConsignments,
        getConsignmentById: getConsignmentById,
        getTrainSummary:getTrainSummary,
        getSummary:getSummary
    });

    function createConsignment( consignment ) {
        var request = $http({
            method: "post",
            crossDomain:true,
            url:  BASE_API + CONSIGNMENT_URI,
            data:consignment
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function updateConsignment( consignment ) {
        var request = $http({
            method: "put",
            crossDomain:true,
            url:  BASE_API + CONSIGNMENT_URI,
            data:consignment
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getConsignmentById(consignmentId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + CONSIGNMENT_URI+ "/" +consignmentId
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getAllConsignments(){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API +  CONSIGNMENT_URI 
        });
        return( request.then( handleSuccess, handleError ) );
    }

      function getTrainSummary(consignmentId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API +  CONSIGNMENT_URI + "/TrainConsignmentSummary/" + consignmentId
        });
        return( request.then( handleSuccess, handleError ) );
    }

       function getSummary(consignmentId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API +  CONSIGNMENT_URI + "/ConsignmentSummary/" + consignmentId
        });
        return( request.then( handleSuccess, handleError ) );
    }

  
});