'use strict';
var CONSIGNMENTTRUCK_URI = "ConsignmentTruck"
var CONSIGNMENT_URI = "Consignment"

services.factory('ConsignmentTruckService', function ($http, $q ) {
    // Return public API.
    return({
        createConsignmentTruck:createConsignmentTruck,
        updateConsignmentTruck:updateConsignmentTruck,
        getAllConsignmentTrucks:getAllConsignmentTrucks,        getAllConsignmentTrucksByConsignmentId:getAllConsignmentTrucksByConsignmentId,
        getConsignmentTruckById: getConsignmentTruckById
    });

    function createConsignmentTruck( consignmentTruck ) {
        var request = $http({
            method: "post",
            crossDomain:true,
            url:  BASE_API + CONSIGNMENTTRUCK_URI,
            data:consignmentTruck
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function updateConsignmentTruck( consignmentTruck ) {
        var request = $http({
            method: "put",
            crossDomain:true,
            url:  BASE_API + CONSIGNMENTTRUCK_URI,
            data:consignmentTruck
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getConsignmentTruckById(consignmentTruckId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + CONSIGNMENTTRUCK_URI+ "/" +consignmentTruckId
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getAllConsignmentTrucks(){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API +  CONSIGNMENTTRUCK_URI 
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getAllConsignmentTrucksByConsignmentId(consignmentId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + CONSIGNMENTTRUCK_URI+ "/" +CONSIGNMENT_URI+ "/" +consignmentId 
        });
        return( request.then( handleSuccess, handleError ) );
    }
  
});