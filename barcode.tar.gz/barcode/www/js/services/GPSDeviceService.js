'use strict';
var GPSDEVICE_URI = "GPSDevice"

services.factory('GPSDeviceService', function ($http, $q ) {
    // Return public API.
    return({
        createGPSDevice:createGPSDevice,
        updateGPSDevice:updateGPSDevice,
        getAllGPSDevices:getAllGPSDevices,
        getGPSDeviceById: getGPSDeviceById
    });

    function createGPSDevice( gPSDevice ) {
        var request = $http({
            method: "post",
            crossDomain:true,
            url:  BASE_API + GPSDEVICE_URI,
            data:gPSDevice
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function updateGPSDevice( gPSDevice ) {
        var request = $http({
            method: "put",
            crossDomain:true,
            url:  BASE_API + GPSDEVICE_URI,
            data:gPSDevice
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getGPSDeviceById(gPSDeviceId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + GPSDEVICE_URI+ "/" +gPSDeviceId
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getAllGPSDevices(){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API +  GPSDEVICE_URI 
        });
        return( request.then( handleSuccess, handleError ) );
    }
  
});