'use strict';
var TRIP_URI = "Trip"
var GPSDEVICE_URI = "GPSDevice"
var TRIPASSIGNSTATUS_URI = "TripAssignStatus"
var TRIPSTATUS_URI = "TripStatus"
var CONSIGNMENTTRUCK_URI = "ConsignmentTruck"

services.factory('TripService', function ($http, $q ) {
    // Return public API.
    return({
        createTrip:createTrip,
        updateTrip:updateTrip,
        getAllTrips:getAllTrips,        
        getAllTripsByGPSDeviceId:getAllTripsByGPSDeviceId,        
        getAllTripsByTripAssignStatusId:getAllTripsByTripAssignStatusId,        
        getAllTripsByTripStatusId:getAllTripsByTripStatusId,
        getTripById: getTripById,
        getAllTripsByConsignmentTruckId:getAllTripsByConsignmentTruckId,
        getCanCreate:getCanCreate,
        getNextAction:getNextAction,
        performNextAction:performNextAction,
        create:create
    });

    function createTrip( trip ) {
        var request = $http({
            method: "post",
            crossDomain:true,
            url:  BASE_API + TRIP_URI,
            data:trip
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function updateTrip( trip ) {
        var request = $http({
            method: "put",
            crossDomain:true,
            url:  BASE_API + TRIP_URI,
            data:trip
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getTripById(tripId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + TRIP_URI+ "/" +tripId
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getAllTrips(){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API +  TRIP_URI 
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getAllTripsByGPSDeviceId(gPSDeviceId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + TRIP_URI+ "/" +GPSDEVICE_URI+ "/" +gPSDeviceId 
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getAllTripsByTripAssignStatusId(tripAssignStatusId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + TRIP_URI+ "/" +TRIPASSIGNSTATUS_URI+ "/" +tripAssignStatusId 
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getAllTripsByTripStatusId(tripStatusId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + TRIP_URI+ "/" +TRIPSTATUS_URI+ "/" +tripStatusId 
        });
        return( request.then( handleSuccess, handleError ) );
    }


    function getAllTripsByConsignmentTruckId(consignmentTruckId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + TRIP_URI+ "/" +CONSIGNMENTTRUCK_URI+ "/" +consignmentTruckId 
        });
        return( request.then( handleSuccess, handleError ) );
    }

    
  
    function getCanCreate(){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + TRIP_URI+ "/CanCreate"
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function performNextAction(tripId,param1,consignmentTruckId,weight){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + TRIP_URI+ "/PerformNextAction/" + tripId + "/Param1/" + param1 + "/ConsignmentTruckId/" + consignmentTruckId + "/Weight/" + weight 
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function getNextAction(tripId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + TRIP_URI+ "/GetNextAction/" + tripId 
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function create(consignmentTruckId){
        var request = $http({
            method: "get",
            crossDomain:true,
            url: BASE_API + TRIP_URI+ "/Create/" +consignmentTruckId    
        });
        return( request.then( handleSuccess, handleError ) );
    }

});
